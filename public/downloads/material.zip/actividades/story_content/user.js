function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5m9uOwTUBz6":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

